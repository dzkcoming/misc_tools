gcc -Wall -lcurl -lssl demo.c -o demo
